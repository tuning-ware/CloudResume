These examples are taken from the draft LZMA specification as published.

This is publishjed by 7-zip.org under

http://www.7-zip.org/sdk.html
