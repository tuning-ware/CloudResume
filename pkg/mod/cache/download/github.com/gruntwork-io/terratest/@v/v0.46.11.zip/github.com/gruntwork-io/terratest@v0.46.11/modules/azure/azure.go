// Package `azure` allows users to interact with resources on the Microsoft Azure platform

package azure
