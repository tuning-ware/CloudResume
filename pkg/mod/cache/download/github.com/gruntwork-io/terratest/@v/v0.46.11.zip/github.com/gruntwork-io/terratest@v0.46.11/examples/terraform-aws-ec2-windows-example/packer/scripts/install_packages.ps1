choco install -y python3
choco install -y git
