---
layout: collection-browser-doc
title: License
category: community
excerpt: >-
  This code is released under the Apache 2.0 License. Read more here.
tags: ["license"]
order: 402
nav_title: Documentation
nav_title_link: /docs/
---

## License

This code is released under the Apache 2.0 License. See [LICENSE](https://github.com/gruntwork-io/terratest/blob/master/LICENSE){:target="_blank"} and [NOTICE](https://github.com/gruntwork-io/terratest/blob/master/NOTICE){:target="_blank"} for more details.
