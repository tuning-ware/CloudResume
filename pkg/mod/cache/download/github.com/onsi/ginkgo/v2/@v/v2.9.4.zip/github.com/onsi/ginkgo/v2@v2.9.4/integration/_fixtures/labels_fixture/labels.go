package labels

var A = Labels("never see")

func Labels(labels ...string) []string {
	return labels
}
