Forked from: https://github.com/go-json-experiment/json
Commit Hash: 540f014424240312547dcccddf11a8229ca0f463

This internal fork exists to prevent dependency issues with go-json-experiment
until its API stabilizes.
